-- Resource Metadata
fx_version 'cerulean'
games {'gta5' }
lua54 'yes'

author 'Bux1k#0001'
description 'Pause Menu (CZ)'
version '1.0'

-- What to run
client_scripts {
    'map.lua'
}

dependency '/assetpacks'